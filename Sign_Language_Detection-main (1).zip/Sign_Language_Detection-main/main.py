import cv2
import HandTrackingModule as htm

# Helper function to safely get landmark data
def safe_get(lst, idx, dim=3):
    return lst[idx] if len(lst) > idx and len(lst[idx]) >= dim else [0]*dim

hCam, wCam = 480, 640
cap = cv2.VideoCapture(0)
cap.set(4, hCam)
cap.set(3, wCam)

detector = htm.HandDetector(detection_con=0.8)

while True:
    success, img = cap.read()
    img = detector.find_hands(img)
    posList = detector.find_position(img, draw=False)
    
    result = ""
    
    if len(posList) != 0:
        fingers = []

        finger_mcp = [5, 9, 13, 17]
        finger_dip = [6, 10, 14, 18]
        finger_pip = [7, 11, 15, 19]
        finger_tip = [8, 12, 16, 20]

        for i in range(4):
            tip = safe_get(posList, finger_tip[i])
            dip = safe_get(posList, finger_dip[i])
            pip = safe_get(posList, finger_pip[i])
            pinky_tip = safe_get(posList, 16)
            pinky_mcp = safe_get(posList, 20)

            if (tip[1] + 25 < dip[1] and pinky_tip[2] < pinky_mcp[2]):
                fingers.append(0.25)
            elif tip[2] > dip[2]:
                fingers.append(0)
            elif tip[2] < pip[2]:
                fingers.append(1)
            elif tip[1] > pip[1] and tip[1] > dip[1]:
                fingers.append(0.5)

        p0 = safe_get(posList, 0)
        p1 = safe_get(posList, 1)
        p3 = safe_get(posList, 3)
        p4 = safe_get(posList, 4)
        p5 = safe_get(posList, 5)
        p6 = safe_get(posList, 6)
        p8 = safe_get(posList, 8)
        p9 = safe_get(posList, 9)
        p10 = safe_get(posList, 10)
        p11 = safe_get(posList, 11)
        p12 = safe_get(posList, 12)
        p16 = safe_get(posList, 16)
        p20 = safe_get(posList, 20)

        if(p3[2] > p4[2]) and (p3[1] > p6[1]) and (p4[2] < p6[2]) and fingers.count(0) == 4:
            result = "A"
        elif(p3[1] > p4[1]) and fingers.count(1) == 4:
            result = "B"
        elif(p3[1] > p6[1]) and fingers.count(0.5) >= 1 and (p4[2] > p8[2]):
            result = "C"
        elif(len(fingers) > 0 and fingers[0] == 1) and fingers.count(0) == 3 and (p3[1] > p4[1]):
            result = "D"
        elif (p3[1] < p6[1]) and fingers.count(0) == 4 and p12[2] < p4[2]:
            result = "E"
        elif (fingers.count(1) == 3) and (fingers[0] == 0) and (p3[2] > p4[2]):
            result = "F"
        elif(len(fingers) > 0 and fingers[0] == 0.25) and fingers.count(0) == 3:
            result = "G"
        elif(len(fingers) > 1 and fingers[0] == 0.25 and fingers[1] == 0.25) and fingers.count(0) == 2:
            result = "H"
        elif (p4[1] < p6[1]) and fingers.count(0) == 3 and len(fingers) > 3 and fingers[3] == 1:
            result = "I"
        elif (p4[1] < p6[1] and p4[1] > p10[1] and fingers.count(1) == 2):
            result = "K"
        elif(len(fingers) > 0 and fingers[0] == 1) and fingers.count(0) == 3 and (p3[1] < p4[1]):
            result = "L"
        elif (p4[1] < p16[1]) and fingers.count(0) == 4:
            result = "M"
        elif (p4[1] < p12[1]) and fingers.count(0) == 4:
            result = "N"
        elif(p4[2] < p8[2]) and (p4[2] < p12[2]) and (p4[2] < p16[2]) and (p4[2] < p20[2]):
            result = "O"
        elif(len(fingers) > 2 and fingers[2] == 0) and (p4[2] < p12[2]) and (p4[2] > p6[2]) and len(fingers) > 3 and fingers[3] == 0:
            result = "P"
        elif(len(fingers) > 3 and fingers[1] == 0 and fingers[2] == 0 and fingers[3] == 0 and p8[2] > p5[2] and p4[2] < p1[2]):
            result = "Q"
        elif(p8[1] < p12[1]) and (fingers.count(1) == 2) and (p9[1] > p4[1]):
            result = "R"
        elif (p4[1] > p12[1]) and p4[2] < p12[2] and fingers.count(0) == 4:
            result = "S"
        elif (p4[1] > p12[1]) and p4[2] < p6[2] and fingers.count(0) == 4:
            result = "T"
        elif (p4[1] < p6[1] and p4[1] < p10[1] and fingers.count(1) == 2 and p3[2] > p4[2] and abs(p8[1] - p11[1]) <= 50):
            result = "U"
        elif (p4[1] < p6[1] and p4[1] < p10[1] and fingers.count(1) == 2 and p3[2] > p4[2]):
            result = "V"
        elif (p4[1] < p6[1] and p4[1] < p10[1] and fingers.count(1) == 3):
            result = "W"
        elif(len(fingers) > 0 and fingers[0] == 0.5 and fingers.count(0) == 3 and p4[1] > p6[1]):
            result = "X"
        elif(fingers.count(0) == 3) and (p3[1] < p4[1]) and len(fingers) > 3 and fingers[3] == 1:
            result = "Y"

        # Display result
        cv2.rectangle(img, (28, 255), (178, 425), (0, 225, 0), cv2.FILLED)
        cv2.putText(img, str(result), (55, 400), cv2.FONT_HERSHEY_COMPLEX, 5, (255, 0, 0), 15)

    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
